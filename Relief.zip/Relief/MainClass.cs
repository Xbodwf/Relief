using System;
using System.Reflection;
using HarmonyLib;
using UnityEngine;
using UnityModManagerNet;
using System.Runtime;
using System.IO;
using Jint;
using Jint.Native;
using System.Xml.Linq;
using System.Text.Json;
using Jint.Native.Object;
using Jint.Native.Function;
using Jint.Runtime;
using Jint.Runtime.Modules;
using static UnityModManagerNet.UnityModManager;
using Jint.Native.Array;
using System.Linq;
using System.Collections;
using UnityEngine.EventSystems;
using Jint.Runtime.Interop;
using System.Threading;
using Relief.Modules.vm;

// TODO: Rename this namespace to your mod's name.
namespace Relief
{
    /// <summary>
    /// The main class for the mod. Call other parts of your code from this
    /// class.
    /// </summary>
    public static class MainClass
    {
        /// <summary>
        /// Whether the mod is enabled. This is useful to have as a global
        /// property in case other parts of your mod's code needs to see if the
        /// mod is enabled.
        /// </summary>
        public static bool IsEnabled { get; private set; }
        public static Engine engine { get; private set; }

        public static Engine transformEngine { get; private set; }

        public static TypeScriptModuleLoader typeScriptLoader { get; private set; }

        static Thread Mainthread;

        public static string AssemblyDirectory
        {
            get
            {
                string codeBase = Assembly.GetExecutingAssembly().CodeBase;
                UriBuilder uri = new UriBuilder(codeBase);
                string path = Uri.UnescapeDataString(uri.Path);
                return Path.GetDirectoryName(path);
            }
        }
        public static string ScriptDir
        {
            get
            {
                return Path.Combine(AssemblyDirectory, "Scripts");
            }
        }

        /// <summary>
        /// UMM's logger instance. Use this to write logs to the UMM settings
        /// window under the "Logs" tab.
        /// </summary>
        public static UnityModManager.ModEntry.ModLogger Logger { get; private set; }

        private static Harmony harmony;

        private static ReactUnityHost _reactUnityHost;
        private static ReactDOM _reactDOM; // Added ReactDOM instance

        /// <summary>
        /// Perform any initial setup with the mod here.
        /// </summary>
        /// <param name="modEntry">UMM's mod entry for the mod.</param>
        internal static void Setup(UnityModManager.ModEntry modEntry)
        {
            Logger = modEntry.Logger;

            // Add hooks to UMM event methods
            modEntry.OnToggle = OnToggle;
            modEntry.OnGUI = Options.OnGUI;
        }

        /// <summary>
        /// Handler for toggling the mod on/off.
        /// </summary>
        /// <param name="modEntry">UMM's mod entry for the mod.</param>
        /// <param name="value">
        /// <c>true</c> if the mod is being toggled on, <c>false</c> if the mod
        /// is being toggled off.
        /// </param>
        /// <returns><c>true</c></returns>
        private static bool OnToggle(UnityModManager.ModEntry modEntry, bool value)
        {
            IsEnabled = value;
            if (value)
            {
                StartMod(modEntry);
            }
            else
            {
                StopMod(modEntry);
            }
            return true;
        }

        /// <summary>
        /// Start the mod up. You can create Unity GameObjects, patch methods,
        /// etc.
        /// </summary>
        /// <param name="modEntry">UMM's mod entry for the mod.</param>
        private static void StartMod(UnityModManager.ModEntry modEntry)
        {
            // Patch everything in this assembly
            harmony = new Harmony(modEntry.Info.Id);
            harmony.PatchAll(Assembly.GetExecutingAssembly());

            Assembly.LoadFile(Path.Combine(AssemblyDirectory, "./JSNet.dll"));
            try
            {
                if (!Directory.Exists(ScriptDir))
                {
                    Directory.CreateDirectory(ScriptDir);
                }

                transformEngine = new Engine(options =>
                {
                    options.EnableModules(ScriptDir);
                    options.ExperimentalFeatures = ExperimentalFeature.All;
                    options.AllowClr();
                });

                var jsConsole = new JsConsole(Logger);

                transformEngine.SetValue("console", jsConsole);

                transformEngine.Execute(Properties.Resources.tsc);

                engine = new Engine(options =>
                {
                    options.EnableModules(ScriptDir);
                    options.ExperimentalFeatures = ExperimentalFeature.All;
                    options.AllowClr();
                });
                engine.SetValue("window", engine);
                engine.SetValue("document", engine);

                engine.SetValue("GameObject", typeof(GameObject));
                engine.SetValue("Transform", typeof(Transform));
                engine.SetValue("Debug", typeof(Debug));

                typeScriptLoader = new TypeScriptModuleLoader(transformEngine, ScriptDir, Logger);

                var eventSystem = new EventSystem();
                var unityBridge = new UnityBridge(engine);
                var reactUnity = new ReactUnity(engine, unityBridge);

                _reactDOM = new ReactDOM(engine, reactUnity);

                // Create a GameObject for ReactUnityHost and add the component
                var hostGameObject = new GameObject("ReactUnityHost");
                _reactUnityHost = hostGameObject.AddComponent<ReactUnityHost>();
                // Initialize ReactUnityHost with a dummy element for now, will be updated by actual render calls
                _reactUnityHost.Initialize(reactUnity.CreateRoot(hostGameObject), JsValue.Undefined);

                var reactModuleCode = @" 
                var React = {};
                React.Fragment = Symbol('react.fragment'); // Define React.Fragment
                
                // Import setStage, useState, and useEffect from ReactUnity
                const { setStage, useState, useEffect } = ReactUnity;

                // Export these functions as part of the React object
                React.setStage = setStage;
                React.useState = useState;
                React.useEffect = useEffect;
                
                // Enhanced createElement with better component support and JSX handling
                React.createElement = (type, props = {}, ...children) => { 
                    // Handle Functional Components
                    if (typeof type === 'function') {
                        return {
                            type: type,
                            props: { ...props, children: children.length === 1 ? children[0] : children },
                            key: props.key || null,
                            $$typeof: Symbol.for('react.element')
                        };
                    }

                    // Handle React.Fragment
                    if (type === React.Fragment) {
                        return {
                            type: React.Fragment,
                            props: { children: children.length === 1 ? children[0] : children },
                            key: props.key || null,
                            $$typeof: Symbol.for('react.element')
                        };
                    }

                    // Handle string elements (HTML-like tags or Unity GameObjects)
                    if (typeof type === 'string') {
                        const gameObjectId = UnityBridge.CreateGameObject(type); 
                        
                        if (props) { 
                            for (const key in props) { 
                                if (key !== 'children' && key !== 'key') {
                                    UnityBridge.SetGameObjectProperty(gameObjectId, key, props[key]); 
                                }
                            } 
                        } 
                        
                        // Process children recursively
                        const processChildren = (childArray) => {
                            childArray.forEach(child => { 
                                if (Array.isArray(child)) {
                                    processChildren(child);
                                } else if (child && typeof child === 'object' && child.gameObject) { 
                                    UnityBridge.SetParent(child.gameObject, gameObjectId); 
                                } else if (child && typeof child === 'object' && child.$$typeof === Symbol.for('react.element')) {
                                    // Handle React elements
                                    const childElement = React.createElement(child.type, child.props, ...(Array.isArray(child.props.children) ? child.props.children : [child.props.children]));
                                    if (childElement && childElement.gameObject) {
                                        UnityBridge.SetParent(childElement.gameObject, gameObjectId);
                                    }
                                } else if (typeof child === 'string' || typeof child === 'number') {
                                    // Handle text content
                                    const textId = UnityBridge.CreateGameObject('Text');
                                    UnityBridge.SetGameObjectProperty(textId, 'name', `Text: ${child}`);
                                    UnityBridge.SetParent(textId, gameObjectId);
                                }
                            });
                        };
                        
                        if (children.length > 0) {
                            processChildren(children);
                        }
                        
                        return { 
                            gameObject: gameObjectId,
                            type: type,
                            props: props,
                            children: children,
                            $$typeof: Symbol.for('react.element')
                        }; 
                    }

                    return null;
                }; 

                // Add component creation helper
                React.Component = class Component {
                    constructor(props) {
                        this.props = props || {};
                        this.state = {};
                    }
                    
                    setState(newState, callback) {
                        this.state = { ...this.state, ...newState };
                        // Trigger re-render (simplified)
                        if (this.render) {
                            this.render();
                        }
                        if (callback && typeof callback === 'function') {
                            callback();
                        }
                    }
                    
                    render() {
                        return null;
                    }
                };

                // Add PureComponent
                React.PureComponent = class PureComponent extends React.Component {
                    shouldComponentUpdate(nextProps, nextState) {
                        // Shallow comparison of props and state
                        return !shallowEqual(this.props, nextProps) || !shallowEqual(this.state, nextState);
                    }
                };

                // Helper function for shallow comparison
                function shallowEqual(obj1, obj2) {
                    const keys1 = Object.keys(obj1);
                    const keys2 = Object.keys(obj2);
                    
                    if (keys1.length !== keys2.length) {
                        return false;
                    }
                    
                    for (let key of keys1) {
                        if (obj1[key] !== obj2[key]) {
                            return false;
                        }
                    }
                    
                    return true;
                }

                // Add memo for functional components
                React.memo = function(Component, areEqual) {
                    return function MemoizedComponent(props) {
                        // This is a simplified implementation
                        // In a real implementation, you'd cache the result based on props
                        return Component(props);
                    };
                };

                export default React;
                ";

                engine.Modules.Add("react", reactModuleCode);

                var reactDOMModuleCode = @"
                import React from 'react';

                export function createRoot(container) {
                    return ReactDOM.CreateRoot(container);
                }

                export function render(element, container, callback) {
                    return ReactDOM.Render(element, container, callback);
                }

                export function unmountComponentAtNode(container) {
                    return ReactDOM.UnmountComponentAtNode(container);
                }

                export function findDOMNode(component) {
                    return ReactDOM.FindDOMNode(component);
                }

                export function createPortal(children, container) {
                    return ReactDOM.CreatePortal(children, container);
                }

                export function flushSync(callback) {
                    return ReactDOM.FlushSync(callback);
                }

                const ReactDOMClient = {
                    createRoot,
                    render,
                    unmountComponentAtNode,
                    findDOMNode,
                    createPortal,
                    flushSync
                };

                export default ReactDOMClient;
                ";
                engine.Modules.Add("react-dom", reactDOMModuleCode);

                // 注册所有内置模块
                BuiltInModules.RegisterAllModules(engine, eventSystem, ScriptDir);

                engine.SetValue<JsConsole>("console", jsConsole);

                Mainthread = new Thread(new ThreadStart(ScanModE));
                Mainthread.Start();
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }
        }

        private static void ScanModE()
        {
            ScanMods(engine);
        }
        /// <summary>
        /// Stop the mod by cleaning up anything that you created in
        /// <see cref="StartMod(UnityModManager.ModEntry)"/>.
        /// </summary>
        /// <param name="modEntry">UMM's mod entry for the mod.</param>
        private static void StopMod(UnityModManager.ModEntry modEntry)
        {
            // Unpatch everything
            harmony.UnpatchAll(modEntry.Info.Id);
            engine = null;

            if (_reactDOM != null)
            {
                _reactDOM.Cleanup();
                _reactDOM = null;
            }

            if (_reactUnityHost != null)
            {
                UnityEngine.Object.Destroy(_reactUnityHost.gameObject);
                _reactUnityHost = null;
            }
        }

        private static void ScanMods(Engine engine)
        {
            if (engine == null) { return; }


            foreach (var directory in Directory.GetDirectories(ScriptDir))
            {
                string projectJsonPath = Path.Combine(directory, "project.json");
                if (!File.Exists(projectJsonPath)) continue;

                string projectJsonContent = File.ReadAllText(projectJsonPath);
                var projectInfo = JsonSerializer.Deserialize<ProjectInfo>(projectJsonContent);

                if (string.IsNullOrEmpty(projectInfo.EntryPoint) || string.IsNullOrEmpty(projectInfo.Export))
                    continue;

                string entryPointFilePath = Path.Combine(directory, projectInfo.EntryPoint);

                if (!File.Exists(entryPointFilePath)) continue;

                // 构建模块路径
                string modulePath = Path.Combine(ScriptDir, $"{Path.GetFileName(directory)}/{projectInfo.EntryPoint}");

                if (projectInfo.EntryPoint.EndsWith(".ts") || projectInfo.EntryPoint.EndsWith(".tsx") || projectInfo.EntryPoint.EndsWith(".jsx"))
                {
                    // Transform TypeScript/JSX to JavaScript
                    string tsCode = File.ReadAllText(entryPointFilePath);
                    var transformResult = typeScriptLoader.TransformTypeScript(tsCode, Path.GetExtension(entryPointFilePath).ToLower(), Path.GetFileName(entryPointFilePath));
                    var transformedCode = transformResult;

                    // Save transformed code to a .js file
                    string jsFilePath = Path.ChangeExtension(entryPointFilePath, ".temp.js");
                    File.WriteAllText(jsFilePath, transformedCode);
                    modulePath = Path.Combine(ScriptDir, $"{Path.GetFileName(directory)}/{Path.GetFileName(jsFilePath)}");
                }
                Logger.Log($"Load Module <color=#debb7b>{projectInfo.Name}</color>");
                try
                {
                    var exports = engine.Modules.Import(modulePath);

                    // 获取导出的函数
                    var exportFunction = exports.Get(projectInfo.Export).AsFunctionInstance();

                    // 调用导出函数
                    exportFunction.Call(engine.Global, new JsValue[] { projectInfo.Id, projectInfo.Name });
                    Logger.Log($"Module <color=#debb7b>{projectInfo.Name}</color> Loaded.");
                }
                catch (Exception ex)
                {
                    Logger.LogException(ex);
                    Logger.Log($"Module <color=#debb7b>{projectInfo.Name}</color> Not Loaded.");
                }


            }
        }

        public class ProjectInfo
        {
            public string Name { get; set; }
            public string Id { get; set; }
            public object[] Authors { get; set; }
            public string EntryPoint { get; set; }
            public string Export { get; set; }
        }




    }
}
